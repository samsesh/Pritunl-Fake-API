from pritunl.static.static import *
from pritunl.static.utils import *
