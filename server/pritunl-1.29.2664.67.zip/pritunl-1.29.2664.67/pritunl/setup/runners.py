def setup_runners():
    from pritunl import runners
    runners.start_all()
