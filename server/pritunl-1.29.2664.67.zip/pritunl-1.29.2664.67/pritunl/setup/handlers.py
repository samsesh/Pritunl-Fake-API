def setup_handlers():
    from pritunl import handlers
