import pritunl.__main__

pritunl.__main__.main('./tools/development_pritunl.conf')
